# textEditor
 This is a Java application which functions as a text editor
